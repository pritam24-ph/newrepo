﻿az vm disk detach \
    -g BFL-AdvAnalyticsGroup-UAT \
	--vm-name AdvAnalytics-UAT-App1\
	-n advanalyticsuatapp1-datadisk-000-20200519-044534