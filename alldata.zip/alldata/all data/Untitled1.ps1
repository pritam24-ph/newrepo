﻿Use below script to check backup failures in last 4 days.
Login-AzAccount

$vault= Get-AzRecoveryServicesVault

for ($i = 0; $i -lt $vault.Count; $i++)

{

Set-AzRecoveryServicesVaultContext -Vault $vault[$i]

$test=Get-AzRecoveryServicesBackupJob -From (Get-Date).AddDays(-4).ToUniversalTime() -Status Failed

if($test -ne 0)

{

$test | Export-Csv "f:\BackupFailedStatus(BFL_AA).csv" -NoTypeInformation -Append

}

}

Open attached BFL_BackupReport.xlsx report and add columns as per the days (N-1).
Prepare the report for both the subscriptions (BFL_Datacenter and BFL_AA)
Use below script to check ongoing backup jobs
 

$vault= Get-AzRecoveryServicesVault

for ($i = 0; $i -lt $vault.Count; $i++)

{

Set-AzRecoveryServicesVaultContext -Vault $vault[$i]

$test=Get-AzRecoveryServicesBackupJob

if($test -ne 0)

{

$test | Export-Csv "f:\backupjobs.csv" -NoTypeInformation -Append

}

}